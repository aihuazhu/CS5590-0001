"""
2. Using NumPy create random vector of size 15 having only Integers in the range 0-20.
Write a program to find the most frequent item/value in the vector list.

"""
import numpy as np

x = np.random.randint(0,20,size=15)
print("the random integer vector is as the following: ")
print(x)
print(np.sort(x))
print(np.bincount(x))
print("the vulue of the most frequent item is ",np.bincount(x).argmax())
#where .bincount(x) count the occurence of each item in x, and .argmax() gives the value of the most frequent occurence
