"""
1. Create a class Employee and then do the following
a. Create a data member to count the number of Employees
b. Create a constructor to initialize name, family, salary, department
c. Create a function to average salary
d. Create a Fulltime Employee class and it should inherit the properties of Employee class
e. Create the instances of Fulltime Employee class and Employee class and call their member functions.
"""

class Employee:                     #1.Create a class Employee
    """A class to represent an Employee"""
    employee_count = 30             #a.Create a data member to count the number of Employees

    def __init__(self,n,f,s,d):     #b.Create a constructor to initialize name, family, salary, department
        self.name = n
        self.family = f
        self.salary = s
        self.department = d

    def get_name(self):
        return self.name

    def get_family(self):
        return self.family

    def get_salary(self):
        return self.salary

    def ave_salary(self):           #c.Create a function to average salary
        aveS=salary/employee_count
        print("the average salary is ",aveS)
        return aveS

class FulltimeEmployee(Employee):   #d.Create a Fulltime Employee class and it should inherit the properties of Employee class
    """A class to represent Fulltime Employee with parent Employee"""
    def __init__(self,n,f,s,d,a):
        Employee.__init__(self,n,f,s,d)
        self.name = n
        self.family = f
        self.salary = s
        self.department = d
        self.add_salary = a

    def newsalary(self):
        self.salary = self.salary + self.add_salary
        return self.salary


#e. Create the instances of Fulltime Employee class and Employee class and call their member functions
x=Employee("John Smith","Ella Smith",5000,"Adminis")
print(x.name)
y=FulltimeEmployee("Bob Miles","Nancy Miles",4000,"Sales",500)
print("the new salary is ", y.newsalary())


