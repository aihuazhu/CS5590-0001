# group 1 ICP3 by Aihua Zhu

# Q1. a. Write a Python program to perform the symmetric difference between two sets
# symmetric difference between sets A and B returns a new set of elements which are in either of the sets but not in both
# that is the (A U B) - (A ^ B)
#      Input: s1= {1,2,4,5}   s2={1,2}
#      Output: {4,5}
#s1=set(input('enter some numbers for set 1 '))
#s2=set(input('enter some numbers for set 2 '))
#print(s1,s2)
s1={1,2,4,5}
s2={1,2}

diff=s1^s2
print("the symmetric difference between two sets: ",diff)

program_pause=input("Press <enter> to continue for the next question ")


# Q1. b. First take a continuous sequence of DNA codon like ‘AAAGGGTTTAAA’ as input and split into individual
# codons as [‘AAA’, ‘GGG’, ‘TTT’, ‘AAA’]
# Then by using the codon table file ( tsv file) print the names of each codon sequence along with their count
# in the form of a dictionary like {'Phenylalanine': 1, 'Lysine': 2, 'Glycine': 1} where {AAA: ‘Lysine’, TTT: ‘Phenylalanine’, ‘GGG’: ‘Glycine’}


CodonSequence=input('enter your Codon sequence such as AAAGGGTTTAAA ')
#splitting the string at 3 and assign it to a list (ref: https://www.geeksforgeeks.org/python-string-split/)
Codonlist=[CodonSequence[i:i+3] for i in range(0,len(CodonSequence),3)]
print(Codonlist)

import csv
from collections import Counter
keylist=[]
dict={}
with open('codon.tsv') as tsvfile:
    reader = csv.reader(tsvfile, delimiter='\t')
    for row in reader:
        for Codon in Codonlist:
            if Codon == row[0]:
             if Codon in dict:
                dict[row[1]] = dict[row[1]] + 1
             else:
                 dict[row[1]] = 1
print(dict)






