#week2: in class exercises from group 1
# Q1:input list and return a tuple with first and last numbers in the list
L=[1,2,3,4,5]           #the input list
T=(L[0],L[len(L)-1])    #the output tuple, where L[0] is the first item, L[len(L)-1] is the last item
print(T)                #print the tuple

# Q2: count the number of words and characters in a file and print the output:
fileName=input('enter the file name ')
infile=open(fileName,'r')
line=infile.readline()
print(line)
nword = 0
nchar = 0

while line !='':
    nword= nword+ len(line.split(' '))
    for ix in line:
        if ix.isalnum():
            nchar += 1
    line=infile.readline()
print('total number of words is ',nword)
print('total number of character is ',nchar)

# Q3: enter the first name and print the shape pattern with stars:
'''
# this code is to print alphabet letters pattern using star symbols
       col
      0123456     0123456   0123456   0123456   0123456   0123456   0123456
    0  *****      ******     ******   ******    *******   *******    *****
    1 *     *     *     *   *         *     *   *         *         *     *
row 2 *     *     *     *   *         *     *   *         *         *
    3 *******     ******    *         *     *   *******   *******   *   ***
    4 *     *     *     *   *         *     *   *         *         *     *
    5 *     *     *     *   *         *     *   *         *         *     *
    6 *     *     ******     ******   ******    *******   *          *****

      0123456     0123456   0123456   0123456   0123456   0123456   0123456
    0 *     *      *****      *****   *   *     *         *     *   *     *
    1 *     *        *          *     *  *      *         **   **   **    *
row 2 *     *        *          *     * *       *         * * * *   * *   *
    3 *******        *          *     **        *         *  *  *   *  *  *
    4 *     *        *      *   *     * *       *     *   *     *   *   * *   
    5 *     *        *      *   *     *  *      *     *   *     *   *    **   
    6 *     *      *****    *****     *   *     *******   *     *   *     *

      0123456     0123456   0123456   0123456   0123456   0123456   
    0  *****      ******     *****    ******    *******   *******
    1 *     *     *     *   *     *   *     *   *     *      *   
row 2 *     *     *     *   *     *   *     *   *            *      
    3 *     *     ******    *   * *   ******    *******      *      
    4 *     *     *         *    **   *     *         *      *
    5 *     *     *          ******   *     *   *     *      *       
    6  *****      *               *   *     *   *******      *     

      0123456     0123456   0123456   0123456   0123456   0123456   
    0 *     *     *     *   *  *  *   *     *   *     *   *******
    1 *     *     *     *   *  *  *    *   *     *   *         *   
row 2 *     *     *     *   *  *  *     * *       * *         *      
    3 *     *     *     *   *  *  *      *         *         *      
    4 *     *      *   *    * * * *     * *        *        *
    5 *     *       * *     **   **    *   *       *       *     
    6  *****         *      *     *   *     *      *      *******       


'''

# define functions that can print different alphabet shape using stars
def Ashape():
    for row in range(7):
        for col in range(7):
            if (((col == 0 or col == 6) and row != 0) or ((row == 0 or row == 3) and (col > 0 and col < 6))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Bshape():
    for row in range(7):
        for col in range(7):
            if ((col == 0) or ((row == 0 or row == 3 or row == 6) and col != 6) or \
                    (col == 6 and (row == 1 or row == 2 or row == 4 or row == 5))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Cshape():
    for row in range(7):
        for col in range(7):
            if ((col == 0 and (row > 0 and row < 6)) or ((row == 0 or row == 6) and col > 0)):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Dshape():
    for row in range(7):
        for col in range(7):
            if ((col == 0) or ((row == 0 or row == 6) and (col < 6 and col > 0)) or \
                    (col == 6 and (row > 0 and row < 6)) or ((row == 0 or row == 6) and (col > 0 and col < 6))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Eshape():
    for row in range(7):
        for col in range(7):
            if (col == 0 or ((row == 0 or row == 3 or row == 6) and col > 0)):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Fshape():
    for row in range(7):
        for col in range(7):
            if (col == 0 or ((row == 0 or row == 3) and col > 0)):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Gshape():
    for row in range(7):
        for col in range(7):
            if (((col == 0 and (row > 0 and row < 6)) or ((row == 0 or row == 6) and (col < 6 and col > 0))) or \
                    (col == 6 and (row == 1 or row == 3 or row == 4 or row == 5)) or (
                            row == 3 and (col == 4 or col == 5))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Hshape():
    for row in range(7):
        for col in range(7):
            if (col == 0 or col == 6 or (row == 3 and (col > 0 and col < 6))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Ishape():
    for row in range(7):
        for col in range(7):
            if (col == 3 or ((row == 0 or row == 6) and (col > 0 and col < 6))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Jshape():
    for row in range(7):
        for col in range(7):
            if (col == 4 or (row == 0 and col > 1) or (row == 6 and col < 5) or (col == 0 and (row > 3))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Kshape():
    for row in range(7):
        for col in range(7):
            if (col == 0 or (row == 3 and col == 1) or ((row == 2 or row == 4) and col == 2) or \
                    ((row == 1 or row == 5) and col == 3) or ((row == 0 or row == 6) and col == 4)):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Lshape():
    for row in range(7):
        for col in range(7):
            if (col == 0 or (row == 6 and col > 0) or ((row == 4 or row == 5) and col == 6)):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Mshape():
    for row in range(7):
        for col in range(7):
            if (col == 0 or col == 6 or (row == 1 and (col == 1 or col == 5)) or \
                    (row == 2 and (col == 2 or col == 4)) or (row == 3 and col == 3)):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Nshape():
    for row in range(7):
        for col in range(7):
            if (col == 0 or col == 6 or (row == 1 and col == 1) or (row == 2 and col == 2) or \
                    (row == 3 and col == 3) or (row == 4 and col == 4) or (row == 5 and col == 5)):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Oshape():
    for row in range(7):
        for col in range(7):
            if (((col == 0 or col == 6) and (row > 0 and row < 6)) or (
                    (row == 0 or row == 6) and (col > 0 and col < 6))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Pshape():
    for row in range(7):
        for col in range(7):
            if (col == 0 or ((row == 0 or row == 3) and (col > 0 and col < 5)) or (col == 6 and (row > 0 and row < 3))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Qshape():
    for row in range(7):
        for col in range(7):
            if (((col == 0 or col == 6) and (row > 0 and row < 5)) or ((row == 0 or row == 5) and (col > 0 and col < 6)) \
                    or (row == 3 and col == 4) or (row == 4 and col == 5) or (row == 6 and col == 6) or (
                            row == 5 and col == 6)):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Rshape():
    for row in range(7):
        for col in range(7):
            if (col == 0 or ((row == 0 or row == 3) and (col > 0 and col < 5)) or (col == 6 and (row > 0 and row < 3)) \
                    or (col == 6 and row > 3)):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Sshape():
    for row in range(7):
        for col in range(7):
            if (row == 0 or row == 3 or row == 6 or (col == 6 and (row == 1 or row == 4 or row == 5)) or \
                    (col == 0 and (row < 4 or row == 5))):
                print("*", end="")
            else:
                print(end=" ")
        print()


def Tshape():
    for row in range(7):
        for col in range(7):
            if (col == 3 or row == 0):
                print("*", end="")
            else:
                print(end=" ")
        print()

#read input first name:
firstname=input('enter your first name: ')
letter=firstname[0].upper()
print(letter)
#
if(letter=='A'):
    Ashape()
if(letter=='B'):
    Bshape()
if(letter=='C'):
    Cshape()
if(letter=='D'):
    Dshape()
if(letter=='E'):
    Eshape()
if(letter=='F'):
    Fshape()
if(letter=='G'):
    Gshape()
if(letter=='H'):
    Hshape()
if(letter=='I'):
    Ishape()
if(letter=='J'):
    Jshape()
if(letter=='K'):
    Kshape()
if(letter=='L'):
    Lshape()
if(letter=='M'):
    Mshape()
if(letter=='N'):
    Nshape()
if(letter=='O'):
    Oshape()
if(letter=='P'):
    Pshape()
if(letter=='Q'):
    Qshape()
if(letter=='R'):
    Rshape()
if(letter=='S'):
    Sshape()
if(letter=='T'):
    Tshape()