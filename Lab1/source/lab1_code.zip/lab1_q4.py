"""
4. Write a python program to create the following management systems.
a. Hospital admission System (e.g. classes Patient, Doctor, Medical Admission Clerk, Book, Nurse,  etc.)

Prerequisites:
a. Your code should have at least five classes
b. Your code should have _init_ constructor in all the classes
c. Your code should show inheritance at least once
d. Your code should have one super call
e. Use of self is required
f. Use at least one private data member in your code
g. Use multiple Inheritance at least once
h. Create instances of all classes and show the relationship between them
Comment your code appropriately to point out where all these things are present
"""

class Patient:
    """A class to represent all Patient"""
    def __init__(self, pid, pn, pa, ps):
        self.patient_ID = pid
        self.patient_name = pn
        self.patient_age = pa
        self.patient_sex = ps
        self.__privateinfo = "not for public"   # this a super private data member with 2 leading under-scores in its name

    def get_patient_information(self):
        print("patient's ID, name, age, sex: ")
        print(self.patient_ID, self.patient_name, self.patient_age, self.patient_sex)
        return self.patient_ID, self.patient_name, self.patient_age, self.patient_sex

class Doctor:
    """A class to represent all Doctor"""
    def __init__(self, dn, da, ds, ddept):
        self.doctor_name = dn
        self.doctor_age = da
        self.doctor_sex = ds
        self.doctor_department = ddept

    def get_doctor_information(self):
        print("doctor's name, age, sex, and department: ")
        print(self.doctor_name, self.doctor_age, self.doctor_sex, self.doctor_department)
        return self.doctor_name, self.doctor_age, self.doctor_sex, self.doctor_department

class Nurse:
    """A class to represent Nurse"""
    def __init__(self, nn, na, ns, ndept):
        self.nurse_name = nn
        self.nurse_age = na
        self.nurse_sex = ns
        self.nurse_department = ndept

    def get_nurse_information(self):
        print("nurse's name, age, sex, and department: ")
        print(self.nurse_name, self.nurse_age, self.nurse_sex, self.nurse_department)
        return self.nurse_name, self.nurse_age, self.nurse_sex, self.nurse_department

class Admission_Clerk:
    """A class to represent Admission Clerk"""
    def __init__(self):
# this is a semi private data with 1 leading under-score in its name
        self._semiprivate_admission = "this is semi private"
# this a super private data with 2 leading under-scores in its name, which can't be seen and accessed from outside
        self.__superprivate_admission = "private, not for public"

class Book:
    """A class to represent doctor's avalaibility"""
    def __init__(self,bdn,bdept,bda):
        self.doctor_name = bdn
        self.department = bdept
        self.availability = bda

class BookedPatient(Patient):
    """A class to represent patient booked appointment with Patient as parent class """
    def __init__(self, pid, pn, pa, ps, bnum):
        Patient.__init__(self, pid, pn, pa, ps)
        self.book_number = bnum

    def get_patient_book_number(self):
        self.book_number += 1
        print("the book number for patient is: ", self.book_number)
        return self.book_number

class BookedDoctor(Doctor):
    """A class to represent doctor booked appointment with Doctor as parent class """
    def __init__(self, dn, da, ds, ddept,bdn):
        super().__init__(dn, da, ds, ddept)
        self.booked_doctor_number = bdn

    def get_doctor_book_number(self):
        print("the number for booked doctor is: ", self.booked_doctor_number)
        return self.booked_doctor_number


xp=Patient(123456,"John Smith",56,"M")
xp.get_patient_information()

yd=Doctor("Nancy Lee",47,"F","Cardiology")
yd.get_doctor_information()

an=Nurse("Jessica Jin",25,"F","Cardiology")
an.get_nurse_information()

nc=Admission_Clerk()
#print(nc.__superprivate_admission)     # this is to test if we can access the super private data from outside
print(nc._semiprivate_admission)

cb=Book("Nancy Lee","Cardiology","NA")
print(cb.availability)

zp=BookedPatient(123456,"John Smith",56,"M",0)
zp.get_patient_book_number()

sd=BookedDoctor("Eric Johnson",45,"M","ICU",3)
sd.get_doctor_book_number()
