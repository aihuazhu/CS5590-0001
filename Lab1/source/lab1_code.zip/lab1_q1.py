# Q1. search in a string and find the first non-repeated characters in that string

# define a function to find the first non-repeated character
def FirstNonRepeat(string):
    for c in string:
# count the occurences of the current character presents and find the 1st one it only shows once
        if string.count(c)==1:
            print('the first non-repeated character is ',c)
            break

sentence=input('enter a sentence ')
sentence=sentence.lower()               # ignore the difference due to capitalization of each word
sentence=sentence.replace(" ","")       # remove all space inside the sentence
FirstNonRepeat(sentence)



