#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Thu Sep 20 12:40:01 2018

@author: azhu
"""
"""
1. Create linear regression model for the dataset at below link using NumPy. Plot the model using matplotlib.
https://umkc.box.com/s/dtqud5vqttj2zsk6yd618yjds9zvxq6c
.
** In the dataset data pairs
    X = national unemployment rate for adult males
    Y = national unemployment rate for adult females
"""
import pandas as pd
import matplotlib.pyplot as plt
import numpy as np

file='slr04.xls'
df = pd.read_excel(file)
x=df['X']
y=df['Y']

mean_x=np.mean(x)
mean_y=np.mean(y)
tnum=len(x)
print('mean x is: ',mean_x)
print('mean y is: ',mean_y)
print('total number of values: ',tnum)

# the linear regression is y=b0+b1*x
# the formular to calculate b1 and b0 is as following:
numerator = 0
denominator = 0
for i in range(tnum):
    numerator += (x[i]-mean_x)*(y[i]-mean_y)
    denominator += (x[i]-mean_x)**2
b1=numerator/denominator
b0=mean_y - (b1 * mean_x)
print('b0 is: ',b0)
print('b1 is: ',b1)

reg_y=b0+b1*x
plt.scatter(x,y,color='red',label='input')
plt.plot(x,reg_y,color='blue',label='regression line')
plt.legend()
plt.show()