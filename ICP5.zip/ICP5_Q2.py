#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 21 17:38:19 2018

@author: azhu
"""

from sklearn.cluster import KMeans
import numpy as np
import matplotlib.pyplot as plt


xv=[1.0,1.5,3.0,5.0,3.5,4.5]
yv=[1.0,2.0,4.0,7.0,5.0,5.0]
X=np.column_stack((xv,yv))
print(X)

kmeans = KMeans(n_clusters=2,max_iter=100, random_state=0).fit(X)
print(kmeans.labels_)
print(kmeans.cluster_centers_)

#plt.scatter(X[:0],X[:1], c=kmeans.labels_, cmap='rainbow')
plt.scatter(xv[0:2],yv[0:2],color='red',label='cluster 1')
plt.scatter(xv[2:],yv[2:],color='blue',label='cluster 2')
plt.legend()
plt.show()
