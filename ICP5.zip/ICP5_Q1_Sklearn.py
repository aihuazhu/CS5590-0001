#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Sep 21 16:20:35 2018

@author: azhu
"""
"""
1. Create linear regression model for the dataset at below link using NumPy. Plot the model using matplotlib.
https://umkc.box.com/s/dtqud5vqttj2zsk6yd618yjds9zvxq6c
.
** In the dataset data pairs
    X = national unemployment rate for adult males
    Y = national unemployment rate for adult females
"""

import csv
import numpy as np
from sklearn import linear_model
import matplotlib.pyplot as plt

xv = []
yv = []

#downloaded data from https://umkc.box.com/s/dtqud5vqttj2zsk6yd618yjds9zvxq6c
def get_data(filename):
    with open(filename, 'r') as csvfile:
        csvFileReader = csv.reader(csvfile)
        next(csvFileReader)  # skipping column names
        for row in csvFileReader:
            xv.append(float(row[0]))
            yv.append(float(row[1]))
    return

def show_plot(xv, yv):
    linear_mod = linear_model.LinearRegression()
    xv = np.reshape(xv, (len(xv), 1))  # converting to matrix of n X 1
    yv = np.reshape(yv, (len(yv), 1))
    linear_mod.fit(xv, yv)  # fitting the data points in the model
    plt.scatter(xv, yv, color='red')  # plotting the initial datapoints
    plt.plot(xv, linear_mod.predict(xv), color='blue', linewidth=3)  # plotting the line made by linear regression
    plt.show()
    return

def predict_price(xv, yv, x):
    linear_mod = linear_model.LinearRegression()  # defining the linear regression model
    xv = np.reshape(xv, (len(xv), 1))  # converting to matrix of n X 1
    yv = np.reshape(yv, (len(yv), 1))
    linear_mod.fit(xv, yv)  # fitting the data points in the model
    predicted_yv = linear_mod.predict(x)
    return predicted_yv[0][0], linear_mod.coef_[0][0], linear_mod.intercept_[0]

get_data('slr04.csv')  # calling get_data method by passing the csv file to it
print("the input x variable is: \n", xv)

print("\n")

print("the input y variable is: \n",yv)

show_plot(xv,yv)    # image of the plot will be generated


